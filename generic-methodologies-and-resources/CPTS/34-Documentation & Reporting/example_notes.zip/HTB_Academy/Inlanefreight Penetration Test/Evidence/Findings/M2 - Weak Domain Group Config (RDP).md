All Domain Users are able to RDP to the DEV01 box (172.16.5.200)


![[Pasted image 20220602184259.png]]

