Directory listing exposing files at http://172.16.5.127/files



![[Pasted image 20220602192717.png]]